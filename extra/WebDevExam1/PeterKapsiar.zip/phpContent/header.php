<header>
    <div class="logoSection">
        <img src="resources/AliExtreme_Logo.png" alt="AliExtremeLogo">
        <p>Extreme Prices</p>
    </div>
    <div class="searchBar">
        <input type="text" placeholder="Search amazing deals...">
    </div>
    <nav>
        <a href="index.php">Cart</a>
        <a href="">Wish List</a>
        <a href="sign-up.php">Sign-Up</a>
    </nav>
</header>