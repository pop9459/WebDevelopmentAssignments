<footer>
    <h2>Help</h2>
    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Vero, accusantium. Obcaecati quidem inventore quod unde quasi modi omnis, non ducimus, dignissimos iusto nihil voluptatem corporis tempore ratione, porro ab consequuntur?</p>
    <h2>Other Assistance</h2>
    <a href="">contact@aliextreme.com</a>
</footer>